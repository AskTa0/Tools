#!/system/bin/sh

while sleep 10
do
ps | busybox grep 'com.android.systemui'
if [ $? = 0 ];then
break;
fi
done 

setenforce 0
